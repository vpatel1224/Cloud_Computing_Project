<?php 

$hostname = "localhost";
$username = "root";
$password = "";
$database = "login_register_hospital";

$conn = mysqli_connect($hostname, $username, $password, $database) or die("Database connection failed");





?>